// src/app/profile-list/profile-list.component.ts
import { Component, OnInit } from '@angular/core';
import { ProfileModule } from './profile/profile.module';


@Component({
  selector: 'app-profile-list',
  templateUrl: './profile-list.component.html',
  styleUrls: ['./profile-list.component.css'],
})
export class ProfileListComponent implements OnInit {
showOnMap(_t3: ProfileModule) {
throw new Error('Method not implemented.');
}
  profiles: ProfileModule[] = [
    {
      id: 1,
      name: 'John Doe',
      description: 'Software Developer',
      address: '123 Main St, City, Country',
    },
    // Add more profiles here
  ];

  constructor() {}

  ngOnInit(): void {}
}
